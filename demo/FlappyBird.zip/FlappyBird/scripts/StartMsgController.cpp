#include "events.hpp"
#include <NTTEngine/NTTEngine.hpp>

class StartMsgController : public Script
{
public:
    StartMsgController(void *data)
    {
    }

    ~StartMsgController()
    {
    }

    void OnEnter() override
    {
        Subscribe(GAME_START_EVENT);
    }

    void OnUpdate(f32 deltaTime) override
    {
    }

protected:
    void OnEvent(
        event_code_t eventCode,
        void *sender,
        const EventContext &context) override
    {
        if (eventCode == GAME_START_EVENT)
        {
            Delete();
        }
    }
};

SCRIPT_DEFINE(StartMsgController, Script);
