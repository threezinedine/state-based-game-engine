
#include <NTTEngine/NTTEngine.hpp>

class StartButtonController : public Script
{
public:
    StartButtonController(void *data)
    {
    }

    ~StartButtonController()
    {
    }

protected:
    void OnHover(HoveringContext &context) override
    {
        if (CHECK_PRESS(NTT_BUTTON_LEFT))
        {
            CloseMenu();
        }
    }
};

SCRIPT_DEFINE(StartButtonController, Script);
