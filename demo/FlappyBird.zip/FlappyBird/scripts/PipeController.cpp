#include "events.hpp"
#include <NTTEngine/NTTEngine.hpp>

class PipeController : public Script
{
public:
    PipeController(void *data)
    {
    }

    ~PipeController()
    {
    }

protected:
    void OnEnterImpl() override
    {
        Subscribe(GAME_OVER_EVENT);
    }

    void OnUpdateImpl(f32 delta) override
    {
        auto geo = GetComponent<Geometry>();

        if (geo->pos.x < -150.0f)
        {
            Delete();
        }

        if (geo->rotation != 0)
        {
            return;
        }

        if (m_created)
        {
            return;
        }

        if (geo->pos.x < 150.0f)
        {
            TriggerEvent(NEW_PIPE_EVENT, nullptr, EventContext());
            TriggerEvent(NEW_SCORE_EVENT, nullptr, EventContext());
            m_created = TRUE;
        }
    }

    void OnEvent(event_code_t eventCode,
                 void *sender,
                 const EventContext &context) override
    {
        if (eventCode == GAME_OVER_EVENT)
        {
            SetComponentState<Mass>(FALSE);
        }
    }

private:
    // used for triggering the NEW_PIPE_EVENT
    b8 m_created = FALSE;
};

SCRIPT_DEFINE(PipeController, Script);
