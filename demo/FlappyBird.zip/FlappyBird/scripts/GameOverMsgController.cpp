#include "events.hpp"
#include <NTTEngine/NTTEngine.hpp>

class GameOverMsgController : public Script
{
public:
    GameOverMsgController(void *data)
    {
    }

    ~GameOverMsgController()
    {
    }

protected:
    void OnEnterImpl() override
    {
        Subscribe(GAME_OVER_EVENT);
        Subscribe(GAME_AGAIN_EVENT);
        SetComponentState<Geometry>(FALSE);
    }

    void OnEvent(event_code_t eventCode,
                 void *sender,
                 const EventContext &context) override
    {
        if (eventCode == GAME_OVER_EVENT)
        {
            SetComponentState<Geometry>(TRUE);
        }
        else if (eventCode == GAME_AGAIN_EVENT)
        {
            SetComponentState<Geometry>(FALSE);
        }
    }
};

SCRIPT_DEFINE(GameOverMsgController, Script);
