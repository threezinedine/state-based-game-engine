
#include <NTTEngine/NTTEngine.hpp>

class PauseButtonController : public Script
{
public:
    PauseButtonController(void *data)
    {
    }

    ~PauseButtonController()
    {
    }

protected:
    void OnHover(HoveringContext &context) override
    {
        if (CHECK_PRESS(NTT_BUTTON_LEFT))
        {
            OpenMenu("menu");
        }
    }
};

SCRIPT_DEFINE(PauseButtonController, Script);
