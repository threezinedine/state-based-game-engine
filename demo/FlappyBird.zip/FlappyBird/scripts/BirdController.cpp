#include "events.hpp"
#include <NTTEngine/NTTEngine.hpp>

class BirdController : public Script
{
public:
    BirdController(void *data)
    {
    }

    ~BirdController()
    {
    }

protected:
    void OnEnterImpl() override
    {
        Subscribe(GAME_START_EVENT);
        Subscribe(GAME_AGAIN_EVENT);
        SetComponentState<Geometry>(FALSE);
        SetComponentState<Mass>(FALSE);
        SetComponentState<Sprite>(FALSE);
        m_isRunning = FALSE;
    }

    void OnUpdateImpl(f32 delta) override
    {
        if (!m_isRunning)
        {
            return;
        }

        auto mass = GetComponent<Mass>();
        auto geo = GetComponent<Geometry>();
        auto texture = GetComponent<TextureComponent>();

        if (mass->velocity_y > 0)
        {
            geo->rotation = 45;
        }
        else if (mass->velocity_y == 0)
        {
            geo->rotation = 0;
        }
        else
        {
            geo->rotation = -45;
        }

        if (CHECK_PRESS(NTT_KEY_SPACE))
        {
            mass->velocity_y = -1.5f;
            PlayAudio(GetResourceID("jump-audio"));
        }
    }

    void OnEvent(
        event_code_t eventCode,
        void *sender,
        const EventContext &context) override
    {
        if (eventCode == GAME_START_EVENT || eventCode == GAME_AGAIN_EVENT)
        {
            m_isRunning = TRUE;
            SetComponentState<Geometry>(TRUE);
            SetComponentState<Mass>(TRUE);
            SetComponentState<Sprite>(TRUE);

            auto mass = GetComponent<Mass>();
            auto geo = GetComponent<Geometry>();

            auto screenSize = GetWindowSize();

            geo->pos.x = 100;
            geo->pos.y = screenSize.height / 2;
            geo->rotation = 0;

            mass->velocity_y = 0;
            mass->velocity_x = 0;
        }
    }

    void OnCollide(List<entity_id_t> others) override
    {
        TriggerEvent(GAME_OVER_EVENT, nullptr, EventContext());
        SetComponentState<Mass>(FALSE);
        SetComponentState<Sprite>(FALSE);
    }

private:
    b8 m_isRunning = FALSE;
};

SCRIPT_DEFINE(BirdController, Script);
