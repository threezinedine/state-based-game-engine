#include "events.hpp"
#include <NTTEngine/NTTEngine.hpp>

class ScoreController : public Script
{
public:
    ScoreController(void *data)
    {
    }

    ~ScoreController()
    {
    }

protected:
    void OnEnterImpl() override
    {
        m_score = 0;
        Subscribe(GAME_START_EVENT);
        Subscribe(GAME_AGAIN_EVENT);
        Subscribe(NEW_SCORE_EVENT);

        f32 numberWidth = 30;
        f32 numberHeight = 50;
        f32 numberGap = 10;
        f32 numberX = 30;
        f32 numberY = 30;

        m_scoreUnitDigit = ECSCreateEntity(
            "score-unit-digit",
            {
                ECS_CREATE_COMPONENT(Geometry, numberX + numberWidth * 2 + numberGap * 2,
                                     numberY, numberWidth, numberHeight, 0, PRIORITY_4),
                ECS_CREATE_COMPONENT(TextureComponent, "numbers-img", 0, 0),
            });

        m_scoreTenthDigit = ECSCreateEntity(
            "score-tenth-digit",
            {
                ECS_CREATE_COMPONENT(Geometry, numberX + numberWidth + numberGap, numberY,
                                     numberWidth, numberHeight, 0, PRIORITY_4),
                ECS_CREATE_COMPONENT(TextureComponent, "numbers-img", 0, 0),
            });

        m_scoreHundredthDigit = ECSCreateEntity(
            "score-hundredth-digit",
            {
                ECS_CREATE_COMPONENT(Geometry, numberX,
                                     numberY, numberWidth, numberHeight, 0, PRIORITY_4),
                ECS_CREATE_COMPONENT(TextureComponent, "numbers-img", 0, 0),
            });
    }

    void OnEvent(event_code_t eventCode, void *sender, const EventContext &context) override
    {
        if (eventCode == GAME_AGAIN_EVENT || eventCode == GAME_START_EVENT)
        {
            m_score = 0;
            UpdateScore();
        }
        else if (eventCode == NEW_SCORE_EVENT)
        {
            m_score++;
            UpdateScore();
        }
    }

    void UpdateScore()
    {
        auto unitDigit = m_score % 10;
        auto tenthDigit = (m_score / 10) % 10;
        auto hundredthDigit = (m_score / 100) % 10;

        auto textureUnitDigit = ECS_GET_COMPONENT(m_scoreUnitDigit, TextureComponent);
        auto textureTenthDigit = ECS_GET_COMPONENT(m_scoreTenthDigit, TextureComponent);
        auto textureHundredthDigit = ECS_GET_COMPONENT(m_scoreHundredthDigit, TextureComponent);

        textureUnitDigit->currentCell.row = unitDigit;
        textureTenthDigit->currentCell.row = tenthDigit;
        textureHundredthDigit->currentCell.row = hundredthDigit;
    }

private:
    u8 m_score = 0;
    entity_id_t m_scoreUnitDigit;
    entity_id_t m_scoreTenthDigit;
    entity_id_t m_scoreHundredthDigit;
};

SCRIPT_DEFINE(ScoreController, Script);
