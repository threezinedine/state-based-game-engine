
#include <NTTEngine/NTTEngine.hpp>

class LogoController : public Script
{
public:
    LogoController(void *data)
    {
    }

    ~LogoController()
    {
    }

    void OnEnter() override
    {
        timer.Reset();
    }

    void OnUpdate(f32 deltaTime) override
    {
        if (timer.GetSeconds() > 2.0f)
        {
            ChangeScene("main");
        }
    }

private:
    Timer timer;
};

SCRIPT_DEFINE(LogoController, Script);
