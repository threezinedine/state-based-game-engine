#include <NTTEngine/NTTEngine.hpp>
#include "events.hpp"

enum GameState
{
    STARTING,
    PLAYING,
    GAMEOVER
};

class MainSceneScript : public Script
{
public:
    MainSceneScript(void *data)
    {
    }

    ~MainSceneScript()
    {
    }

protected:
    void OnEnterImpl() override
    {
        state = STARTING;
        Subscribe(GAME_OVER_EVENT);
        Subscribe(NEW_PIPE_EVENT);
    }

    void OnUpdateImpl(float dt) override
    {
        switch (state)
        {
        case STARTING:
            OnStartingState();
            break;
        case PLAYING:
            OnPlayingState();
            break;
        case GAMEOVER:
            OnGameOverState();
            break;
        }
    }

    void OnStartingState()
    {
        if (CHECK_PRESS(NTT_KEY_SPACE))
        {
            state = PLAYING;
            TriggerEvent(GAME_START_EVENT, nullptr, EventContext());
            OnEnterPlaying();
        }
    }

    void OnPlayingState()
    {
    }

    void OnGameOverState()
    {
        if (CHECK_PRESS(NTT_KEY_SPACE))
        {
            state = PLAYING;
            TriggerEvent(GAME_AGAIN_EVENT, nullptr, EventContext());
            OnEnterPlaying();
        }
    }

    void OnEvent(event_code_t eventCode, void *sender, const EventContext &context) override
    {
        if (eventCode == GAME_OVER_EVENT)
        {
            state = GAMEOVER;
        }
        else if (eventCode == NEW_PIPE_EVENT)
        {
            CreatePipe();
        }
    }

    void OnEnterPlaying()
    {
        for (auto pipe : m_pipes)
        {
            ECSDeleteEntity(pipe);
        }

        CreatePipe();
    }

    void CreatePipe()
    {
        String pipeTopName = GetName("pipe-top");
        String pipeBottomName = GetName("pipe-bottom");
        auto screenSize = GetWindowSize();
        f32 pipeWidth = 70;
        f32 pipeHeight = 500;
        f32 pipeGap = 150;

        f32 pipeTopY = Random(70.0f - pipeHeight / 2, screenSize.height - 300.0f - pipeGap);
        f32 pipeBottomY = pipeTopY + pipeGap + pipeHeight;

        auto pipeTop = ECSCreateEntity(
            pipeTopName,
            {
                ECS_CREATE_COMPONENT(Geometry, screenSize.width + pipeWidth / 2,
                                     pipeTopY,
                                     pipeWidth, pipeHeight,
                                     180),
                ECS_CREATE_COMPONENT(TextureComponent, "pipe-img", 0, 0),
                ECS_CREATE_COMPONENT(Mass, 1.0f, -1.5f),
                ECS_CREATE_COMPONENT(Collision),
                ECS_CREATE_COMPONENT(NativeScriptComponent, "pipe-controller"),
            });

        auto pipeBottom = ECSCreateEntity(
            pipeBottomName,
            {
                ECS_CREATE_COMPONENT(Geometry, screenSize.width + pipeWidth / 2,
                                     pipeBottomY,
                                     pipeWidth, pipeHeight),
                ECS_CREATE_COMPONENT(TextureComponent, "pipe-img", 0, 0),
                ECS_CREATE_COMPONENT(Mass, 1.0f, -1.5f),
                ECS_CREATE_COMPONENT(Collision),
                ECS_CREATE_COMPONENT(NativeScriptComponent, "pipe-controller"),
            });

        m_pipes.push_back(pipeTop);
        m_pipes.push_back(pipeBottom);
    }

private:
    GameState state;
    List<entity_id_t> m_pipes;
};

SCRIPT_DEFINE(MainSceneScript, Script);
